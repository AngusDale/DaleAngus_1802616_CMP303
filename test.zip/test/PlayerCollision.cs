using Godot;
using System;

public class PlayerCollision : Area2D
{
    public override void _Ready(){
    }
    public void OnEnter(Node collision){
        
    }
}
